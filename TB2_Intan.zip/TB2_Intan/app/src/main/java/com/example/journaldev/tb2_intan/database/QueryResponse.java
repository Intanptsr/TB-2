package com.example.journaldev.tb2_intan.database;

public interface QueryResponse<T> {
    void onSuccess(T data);
    void onFailure(String message);
}