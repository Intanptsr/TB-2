package com.example.journaldev.tb2_intan.features.taken_subject_crud;

public interface TakenSubjectCrudListener {
    void onTakenSubjectUpdated(boolean isUpdated);
}
